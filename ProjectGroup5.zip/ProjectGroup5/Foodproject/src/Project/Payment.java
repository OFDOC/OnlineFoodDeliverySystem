package Project;

import java.util.Scanner;

public class Payment extends Menu{

  //public static void main(String[] args) {
        // TODO Auto-generated method stub

  public void payment() {
                // TODO Auto-generated method stub

@SuppressWarnings("resource")
Scanner sc= new Scanner(System.in);
System.out.println("Enter 1 for SBI, 2 for ICICI Bank or enter any number for other banks");
//User should enter above any one number
int bank = sc.nextInt();
switch(bank) {
case 1: 
System.out.println("You choose SBI");
break;
case 2:
System.out.println("You choose ICICI");
break;
default: System.out.println("Other banks");
break;
}
System.out.println("Enter 1 for Credit Card, Enter 2 for Debit Card");
//User should enter above any one number
int button= sc.nextInt();
switch(button) {
case 1:
System.out.println("Credit Card");
System.out.println("Enter Card Number: ");
    String C_cardNumber=sc.next();
    if(C_cardNumber.matches("[0-9]{16}")) {
System.out.println("Enter Card Holder Name: ");
    String C_holderName=sc.next();
System.out.println("Enter CVV: ");
    String cvv=sc.next();
    if(cvv.matches("[0-9]{3}")) {
System.out.println("Pay Now");
System.out.println("Payment Successfull");
    }else {
    	System.out.println("(: ******  You are card number is invalid. you can re-enter all details again  ****** :)");
    payment();
    }
    }else {
    	System.out.println("(: ******  You are card number is invalid. you can re-enter all details again  ****** :)");
        payment();
    }
break;

 

case 2: System.out.println("Debit Card");
System.out.println("Enter Card Number: ");
    String D_cardNumber=sc.next();
    if(D_cardNumber.matches("[0-9]{16}")) {
System.out.println("Enter Card Holder Name: ");
    String D_holderName=sc.next();
System.out.println("Enter CVV: ");
    String D_cvv=sc.next();
    if(D_cvv.matches("[0-9]{3}")) {
System.out.println("Pay Now");
System.out.println("Payment Successfull");
}else {
	System.out.println("(: ******  You are card number is invalid. you can re-enter all details again  ****** :)");
payment();
}
}else {
	System.out.println("(: ******  You are card number is invalid. you can re-enter all details again  ****** :)");
    payment();
}
break;

 

default: {
System.out.println("Enter 1 for Credit Card, Enter 2 for Debit Card");
//User should enter above any one number
int button1= sc.nextInt();
System.out.println("Enter Card Number: ");
String A_cardNumber=sc.next();
if(A_cardNumber.matches("[0-9]{16}")) {
System.out.println("Enter Card Holder Name: ");
String A_holderName=sc.next();
System.out.println("Enter CVV: ");
String A_cvv=sc.next();
if(A_cvv.matches("[0-9]{3}")) {
System.out.println("Pay Now");
System.out.println("Payment Successfull");
}else {
	System.out.println("(: ******  You are card number is invalid. you can re-enter all details again  ****** :)");
payment();
}
}else {
	System.out.println("(: ******  You are card number is invalid. you can re-enter all details again  ****** :)");
    payment();
}
break;
}
}

}
}

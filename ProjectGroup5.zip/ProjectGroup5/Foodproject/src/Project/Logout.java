package Project;

import java.sql.SQLException;
import java.util.Scanner;
        public class Logout extends Payment{
        //public static void main(String []args) {
        public void logout() throws SQLException {
                @SuppressWarnings("resource")
                Scanner sc= new Scanner(System.in);
                System.out.println("Please Rate Us");
                //User should enter only numbers
                int stars = sc.nextInt();
                switch(stars) {
                case 1: System.out.println("You rated 1");
                break;
                case 2: System.out.println("You rated 2");
                break;
                case 3: System.out.println("You rated 3");
                break;
                case 4: System.out.println("You rated 4");
                break;
                case 5: System.out.println("You rated 5");
                break;
                default: System.out.println("Thank you for not rating us please take time to rate us later.");
                break;
                }
                System.out.println("Do you want to Logout?");
                System.out.println("Enter Yes or No");
                String Logout = sc.next();
                if("yes".contentEquals(Logout)) {
                System.out.println("Logout Successfull");
                            }
                else {
                System.out.println("Logout Failed");
                menu();
                }
        }
        }    
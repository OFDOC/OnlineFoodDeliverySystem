package Project;

import java.sql.*;
import java.util.Scanner;

public class Login extends Registration{
	public void login() throws SQLException { 
	//public static void main(String[] args) throws SQLException {
		Driver d= new oracle.jdbc.driver.OracleDriver();
		DriverManager.registerDriver(d);			
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","FOODDELIVERY","project");
		Statement stmt=con.createStatement();
		Scanner sc=new Scanner(System.in);
		//User or admin only enter 25 characters
		System.out.print("Enter UserName: ");
		String username=sc.nextLine();
		System.out.print("Enter Password: ");
		//User or admin only enter 25 characters
		String password=sc.next();
		ResultSet rs=stmt.executeQuery("select * from login where username='"+username+"' and password='"+password+"'");
		if(rs.next()) {
		System.out.println("(:    Welcome to food delivery system    :)");
		}else {
			System.out.println("(: *** Invalid Password and Username *** :)" +"\n"+ "(: *** please re-enter password and username *** :)");
		login();
			
		
		}
		con.close();
		}

}
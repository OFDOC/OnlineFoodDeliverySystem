package Project;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Location extends Login{
	//public static void main(String[] args) throws SQLException {
        // TODO Auto-generated method stub
		public void location() throws SQLException {
		Driver d= new oracle.jdbc.driver.OracleDriver();
		DriverManager.registerDriver(d);		
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","FOODDELIVERY","project");
		Statement stmt=con.createStatement();
		Scanner sc=new Scanner(System.in);
		System.out.println("*********         Welcome To Location Module       **********");
		System.out.println("Enter your Address: ");
		//User or admin only enter 25 characters
		String address=sc.next();
		sc.nextLine();
		System.out.println("Enter your City: ");
		//User or admin only enter 20 characters
		String city=sc.next();
		System.out.println("Enter your State: ");
		//User or admin only enter 20 characters
		String state=sc.next();
		System.out.println("Enter your Pin Code: ");
		//User or admin only enter 6 numbers not taking alphabetic characters 
		String pinCode=sc.next();
		if(pinCode.matches("[0-9]{6}")) {
		ResultSet rs=stmt.executeQuery("insert into Location values ('"+address+"','"+city+"','"+state+"','"+pinCode+"')");
		System.out.println("Sucsessfully Saved your Address");
		PreparedStatement stmt1=con.prepareStatement("select * from Location");
		ResultSet result=stmt1.executeQuery();
		while(result.next()) {
			System.out.println("(: *** Your Location Details *** :)");
			System.out.println(" Address : "+result.getString(1)+"\n City : "+result.getString(2)+"\n State : "+result.getString(3)+"\n Pin Code : "+result.getString(4));
		}
		
		
	}else {
		System.out.println("Re-Enter your pin code");
		location();
	}

}
}
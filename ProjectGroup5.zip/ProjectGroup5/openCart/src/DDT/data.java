package DDT;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class data {
	//We have taken data from excel using Apache POI for Login 
	@DataProvider(name = "Login"/*parallel = true*/)
	public Object[][] Login() throws FileNotFoundException, IOException {
		XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(new File(".//data.xlsx")));
		XSSFSheet sheet = workbook.getSheet("Sheet1");
		int rows = sheet.getPhysicalNumberOfRows();
		int col = sheet.getRow(0).getPhysicalNumberOfCells();
		DataFormatter df = new DataFormatter();
		Object[][] login = new Object[rows][col];
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < col; j++) {
				login[i][j] = df.formatCellValue(sheet.getRow(i).getCell(j));
			}
		}
		return login;
	}
	//We have taken data from excel using Apache POI for Registration
	@DataProvider(name = "Registration"/*parallel = true*/)
	public Object[][] Registration() throws FileNotFoundException, IOException {
		XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(new File(".//data.xlsx")));
		XSSFSheet sheet = workbook.getSheet("Sheet2");
		int rows = sheet.getPhysicalNumberOfRows();
		int col = sheet.getRow(0).getPhysicalNumberOfCells();
		DataFormatter df = new DataFormatter();
		Object[][] login = new Object[rows][col];
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < col; j++) {
				login[i][j] = df.formatCellValue(sheet.getRow(i).getCell(j));
			}
		}
		return login;
	}
}

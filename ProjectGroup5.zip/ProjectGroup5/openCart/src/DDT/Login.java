package DDT;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.reporter.configuration.ViewName;

import POM.login;

public class Login extends Base {
	@BeforeTest
	public void start() {
		spark = new ExtentSparkReporter(".//reports/loginDDT.html");
		report = new ExtentReports();
		report.attachReporter(spark);
		test = report.createTest("Login");
		spark.viewConfigurer().viewOrder().as(new ViewName[] { ViewName.DASHBOARD, ViewName.TEST, ViewName.AUTHOR,
				ViewName.DEVICE, ViewName.EXCEPTION, ViewName.LOG }).apply().config().setTheme(Theme.DARK);
	}
//Launch to Login page
	@BeforeMethod
	public void launch() {
		launchChrome();
		driver.get(LoginLink);

	}
//If it is navigated to dashboard the test is passed or else failed
	//The credentials are taken from excel file using Apache POI
	@Test(dataProvider = "Login", dataProviderClass = data.class)
	public void testLogin(String email, String pass) {
		if (driver.getCurrentUrl().equals(LoginLink))
			test.log(Status.PASS, "Navigated to Login page");
		else
			test.log(Status.FAIL, "Couldn't navigate to Login Page");
		Login = new login(driver);
		Login.setEmail(email);
		test.pass("Entered email : " + email);
		Login.setPassword(pass);
		test.pass("Entered pass : " + pass);
		Login.clkLogin();
		test.pass("Clicked Login Button");
		if (!driver.getCurrentUrl().equals(LoginLink))
			test.log(Status.PASS, "Logged in");
		else
			test.log(Status.FAIL, "Couldn't Login");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	//If the test is failed it will display fail with screenshot added to it.
	@AfterMethod
	public void tearDown(ITestResult result) {
		if (!result.isSuccess()) {
			test.fail(result.getThrowable());
			test.addScreenCaptureFromBase64String(((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64));
		}
		driver.close();
	}


	@AfterTest
	public void flush() {
		report.flush();
	}
}

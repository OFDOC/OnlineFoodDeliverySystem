package DDT;

import java.lang.reflect.Method;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.reporter.configuration.ViewName;

import POM.Register;

public class registration extends Base {
	@BeforeTest
	public void start() {
		spark = new ExtentSparkReporter(".//reports/registration.html");
		report = new ExtentReports();
		report.attachReporter(spark);
		spark.viewConfigurer().viewOrder().as(new ViewName[] { ViewName.DASHBOARD, ViewName.TEST, ViewName.AUTHOR,
				ViewName.DEVICE, ViewName.EXCEPTION, ViewName.LOG }).apply().config().setTheme(Theme.DARK);
		test = report.createTest("testRegistration");
		test.assignAuthor("Dheekshitha");
		test.assignDevice("Windows 11");
	}
	
	//Launched to Registration Module
	@BeforeMethod
	public void launch() {
		launchChrome();
		driver.get(RegistrationLink);
	}
	
	//If it is navigated to dashboard the test is passed or else failed
	//The credentials are taken from excel file using Apache POI
	
	@Test(dataProvider = "Registration", dataProviderClass = data.class)
	public void testRegistration(String fname, String lname, String email, String pass) {
		if (driver.getCurrentUrl().equals(RegistrationLink))
			{test.log(Status.PASS, "Navigated to URL");}
		else
		{ test.log(Status.FAIL, "Couldn't navigate to URL");}
		reg = new Register(driver);
		reg.setFName(fname);
		test.pass("Entered FirstName : " + fname);
		reg.setLName(lname);
		test.pass("Entered LastName : " + lname);
		reg.setEmail(email);
		test.pass("Entered email : " + email);
		reg.setPassword(pass);
		test.pass("Entere password : " + pass);
		reg.clkAgree();
		test.pass("CheckBox clicked");
		reg.clkContinue();
		if (!driver.getCurrentUrl().equals(RegistrationLink))
			{test.log(Status.PASS, "Navigated to Login Page");}
		else
			{test.log(Status.FAIL, "Couldn't navigate to URL");
			}
		}
	//If the test is failed it will display fail with screenshot added to it.
	@AfterMethod
	public void tearDown(ITestResult result) {
		if (!result.isSuccess()) {
			test.fail(result.getThrowable());
			test.addScreenCaptureFromBase64String(((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64));
		}
		driver.close();
	}

	@AfterTest
	public void flush() {
		report.flush();
	}
}

package TestCases;

import java.lang.reflect.Method;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.reporter.configuration.ViewName;

import POM.dashboard;

public class productsInDashBoard extends Base {
	@BeforeTest
	public void start() {
		spark = new ExtentSparkReporter(".//reports/dashboard.html");
		report = new ExtentReports();
		report.attachReporter(spark);
		spark.viewConfigurer().viewOrder().as(new ViewName[] { ViewName.DASHBOARD, ViewName.TEST, ViewName.AUTHOR,
				ViewName.DEVICE, ViewName.EXCEPTION, ViewName.LOG }).apply().config().setTheme(Theme.DARK);

	}
//Launch to dashboard
	@BeforeMethod
	public void launch() {
		launchChrome();
		driver.get(Dashboard);
	}
//If it is navigated to dashboard the test is passed or else failed
	@Test
	public void testDashboard(Method m) {
		test = report.createTest(m.getName()).assignAuthor("Dheekshitha").assignDevice("Windows 11");
		d = new dashboard(driver);
		if (driver.getCurrentUrl().equals(Dashboard))
			test.log(Status.PASS, "Navigated to Dashboard");
		else
			test.log(Status.FAIL, "Couldn't navigate to Dashboard");
		d.printDetails();
		test.pass("Printed Details in Console");

	}
//If the test is failed it will display fail with screenshot added to it.
	@AfterMethod
	public void tearDown(ITestResult result) {
		if (!result.isSuccess()) {
			test.fail(result.getThrowable());
			test.addScreenCaptureFromBase64String(((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64));
		}
		driver.close();
	}


	@AfterTest
	public void flush() {
		report.flush();
	}
}

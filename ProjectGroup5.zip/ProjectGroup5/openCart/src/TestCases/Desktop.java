package TestCases;

import java.lang.reflect.Method;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.reporter.configuration.ViewName;

public class Desktop extends Base {
	@BeforeTest
	public void start() {
		spark = new ExtentSparkReporter(".//reports/Desktops.html");
		report = new ExtentReports();
		report.attachReporter(spark);
	}
//It will launch Home page
	@BeforeMethod
	public void launch() {
		launchChrome();
		driver.get(home);
		spark.viewConfigurer().viewOrder().as(new ViewName[] { ViewName.DASHBOARD, ViewName.TEST, ViewName.AUTHOR,
				ViewName.DEVICE, ViewName.EXCEPTION, ViewName.LOG }).apply().config().setTheme(Theme.DARK);
	}
/*If it is navigated to dashboard the test is passed or else failed.
 We have tested PC, MAC, IMAC and Add to cart buttons*/
	@Test
	public void testDeskTops(Method m) {
		test = report.createTest(m.getName()).assignAuthor("Dheekshitha").assignDevice("Windows 11");
		h = new POM.home(driver);
		// h.moveToDesktop();
		if (driver.getCurrentUrl().equals(home))
			test.pass("Navigated to URL");
		else
			test.fail("Couldn't navigate to URL");
		h.clkPC();
		test.pass("Clicked PC");
		h.clkMac();
		test.pass("Clicked Mac");
		h.clkIMac();
		test.pass("Clicked IMac");
		h.clkAddTocart();
		test.pass("Clicked AddToCart");
	}
//If it is navigated to dashboard the test is passed or else failed
	//We have tested Laptops, HP, Add to cart buttons
	@Test
	public void testLaptoptops(Method m) {
		test = report.createTest(m.getName()).assignAuthor("Dheekshitha").assignDevice("Windows 11");
		
		if (driver.getCurrentUrl().equals(home))
			test.pass("Navigated to URL");
		else
			test.fail("Couldn't navigate to URL");
		h = new POM.home(driver);

		h.clkLaptop();
		test.pass("Clicked Latops");
		h.clkHp();
		test.pass("Clicked HP");
		h.clkAddTocart();
		test.pass("Clicked Added to Cart");
	}
//If it is navigated to dashboard the test is passed or else failed
	// tested Components, Monitors, Samsung, Add to cart buttons
	@Test
	public void testMonitors(Method m) {
		test = report.createTest(m.getName()).assignAuthor("Dheekshitha").assignDevice("Windows 11");
		;
		if (driver.getCurrentUrl().equals(home))
			test.pass("Navigated to URL");
		else
			test.fail("Couldn't navigate to URL");
		h = new POM.home(driver);
		h.clkComponents();
		test.pass("Clicked Components");
		h.clkMonitors();
		test.pass("Clicked Monitors");
		h.clkSamsung();
		test.pass("Clicked Samsung");
		h.clkAddTocart();
		test.pass("Added To Cart");
	}
	//If it is navigated to dashboard the test is passed or else failed
		//tested Tablets, SamsungGtab, Add to cart buttons
	@Test
	public void testTablets(Method m) {
		test = report.createTest(m.getName()).assignAuthor("Dheekshitha").assignDevice("Windows 11");
		;
		if (driver.getCurrentUrl().equals(home))
			test.pass("Navigated to URL");
		else
			test.fail("Couldn't navigate to URL");
		h = new POM.home(driver);
		h.clkTablets();
		test.pass("Clicked Tablets");
		h.clkSamsungGTab();
		test.pass("Clicked samsungGTab");
		h.clkAddTocart();
		test.pass("Added To cart");
	}
	//If it is navigated to dashboard the test is passed or else failed
		//We have tested Phones, HTC, Add to cart buttons
	@Test
	public void testPhone(Method m) {
		test = report.createTest(m.getName()).assignAuthor("Dheekshitha").assignDevice("Windows 11");
		;
		if (driver.getCurrentUrl().equals(home))
			test.pass("Navigated to URL");
		else
			test.fail("Couldn't navigate to URL");
		h = new POM.home(driver);
		h.clkPhones();
		test.pass("Clicked Phones");
		h.clkHTC();
		test.pass("Clicked HTC ");
		h.clkAddTocart();
		test.pass("Clicked Add to cart");

	}
//If the test is failed it will display fail with screenshot added to it.
	@AfterMethod
	public void tearDown(ITestResult result) {
		if (!result.isSuccess()) {
			test.fail(result.getThrowable());
			test.addScreenCaptureFromBase64String(((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64));
		}
		driver.close();
	}

	@AfterTest
	public void flush() {
		report.flush();
	}
}

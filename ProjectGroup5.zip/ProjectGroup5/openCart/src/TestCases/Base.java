package TestCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import POM.Register;
import POM.dashboard;
import POM.home;
import POM.login;

public class Base {
	static ExtentSparkReporter spark;
	static ExtentReports report;
	static ExtentTest test;
	static final String RegistrationLink = "https://demo.opencart.com/index.php?route=account/register";
	static final String LoginLink = "https://demo.opencart.com/index.php?route=account/login";
	static final String Dashboard = "https://demo.opencart.com/index.php?route=common/home&language=en-gb";
	static final String home = "https://demo.opencart.com/index.php?route=common/home";
	static WebDriver driver;
	Register reg;
	login Login;
	dashboard d;
	home h;

	public void launchChrome() {
//		WebDriverManager.chromedriver().setup();
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\guduru.dheekshitha\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		driver = new ChromeDriver(/* (new ChromeOptions()).setHeadless(true) */);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public void launchEdge() {
		//WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

}

package POM;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseClass {
	static WebDriver driver;
	static WebDriverWait wait;
	JavascriptExecutor js;
	static Actions act;

	public void waitFor(WebElement element) {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void moveTo(WebElement element) {
		js = (JavascriptExecutor) driver;
		int x = element.getLocation().getX();
		int y = element.getLocation().getY();
		js.executeScript("scrollTo(" + x + "," + y + ")");
	}

	public void click(WebElement element) {
		js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", element);
	}

}

package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Register extends BaseClass {
	public Register(WebDriver driver) {
		this.driver = driver;
	}
//Tested registration module using xpath
	//Enter First name
	By fName = By.xpath("//input[@id='input-firstname']");

	public void setFName(String fname) {
		driver.findElement(fName).sendKeys(fname);
	}
//Enter Last name
	By lName = By.xpath("//input[@id='input-lastname']");

	public void setLName(String lname) {
		waitFor(driver.findElement(lName));
		driver.findElement(lName).sendKeys(lname);
	}
//Enter Email
	By email = By.xpath("//input[@id='input-email']");

	public void setEmail(String emailT) {
		waitFor(driver.findElement(email));
		driver.findElement(email).sendKeys(emailT);
	}
//Enter password
	By passWord = By.xpath("//input[@id='input-password']");

	public void setPassword(String pass) {
		waitFor(driver.findElement(passWord));
		driver.findElement(passWord).sendKeys(pass);
	}
//Click checkbox
	By checkBox = By.xpath("//input[@name='agree']");

	public void clkAgree() {
		waitFor(driver.findElement(checkBox));
		moveTo(driver.findElement(checkBox));
		click(driver.findElement(checkBox));
	}
//Click on continue to complete registration
	By Continue = By.xpath("//button[text()='Continue']");

	public void clkContinue() {
		waitFor(driver.findElement(Continue));
		click(driver.findElement(Continue));
	}
}

package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class home extends BaseClass {
	public home(WebDriver driver) {
		this.driver = driver;
	}
//Tested each module using xpath
	
	By Desktop = By.xpath("//a[text()='Desktops']");

	public Actions moveToDesktop() {
		act = new Actions(driver);
		act.moveToElement(driver.findElement(Desktop)).perform();
		return act;
	}

	By pc = By.xpath("//a[text()='PC (0)']");

	public void clkPC() {
		act = new Actions(driver);
		act.moveToElement(driver.findElement(Desktop)).click(driver.findElement(pc)).perform();
	}

	By mac = By.xpath("(//div[@class='list-group mb-3']/a)[3]");

	public void clkMac() {
		driver.findElement(mac).click();
	}

	By iMac = By.xpath("//div[@class='col']//div[@class='image']/a");

	public void clkIMac() {
		driver.findElement(iMac).click();
	}

	By addToCart = By.xpath("//button[text()='Add to Cart']");

	public void clkAddTocart() {
		driver.findElement(addToCart).click();
	}

	By laptop = By.xpath("//a[text()='Laptops & Notebooks']");

	public void clkLaptop() {
		driver.findElement(laptop).click();
	}

	By hpLaptop = By.xpath("(//div[@class='col']//div[@class='image'])[1]/a");

	public void clkHp() {
		driver.findElement(hpLaptop).click();
	}

	By components = By.xpath("//a[text()='Components']");

	public void clkComponents() {
		driver.findElement(components).click();
	}

	By monitors = By.xpath("//a[text()='Monitors (2)']");

	public void clkMonitors() {
		act = new Actions(driver);
		act.moveToElement(driver.findElement(monitors)).click(driver.findElement(monitors)).perform();
	}

	By samsung = By.xpath("//div[@class='col'][2]//div[@class='image']/a");

	public void clkSamsung() {
		driver.findElement(samsung).click();
	}

	By tablets = By.xpath("//a[text()='Tablets']");

	public void clkTablets() {
		driver.findElement(tablets).click();
	}

	By samsungGTab = By.xpath("//div[@class='col']//div[@class='image']/a");

	public void clkSamsungGTab() {
		driver.findElement(samsungGTab).click();
	}

	By phones = By.xpath("//a[text()='Phones & PDAs']");

	public void clkPhones() {
		driver.findElement(phones).click();
	}

	By htc = By.xpath("(//div[@class='col']//div[@class='image']/a)[1]");
	public void clkHTC() {
		driver.findElement(htc).click();
	}
}

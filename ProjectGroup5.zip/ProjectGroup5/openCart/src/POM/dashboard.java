package POM;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class dashboard extends BaseClass {
	public dashboard(WebDriver driver) {
		this.driver = driver;
	}

	By productName = By.xpath("//h4");
	By productPrice = By.xpath("(//h4/following-sibling::div)/span[1]");

	public void printDetails() {
		List productNames = driver.findElements(productName);
		List ProductPrice = driver.findElements(productPrice);
		Iterator<WebElement> nameit = productNames.iterator();
		Iterator<WebElement> priceit = ProductPrice.iterator();
		for (int i = 0; i < productNames.size(); i++) {
			System.out.println((nameit.next()).getText() + " : " + (priceit.next()).getText());
		}
	}
}

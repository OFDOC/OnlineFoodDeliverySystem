package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class login extends BaseClass {

	public login(WebDriver driver) {
		this.driver = driver;
	}
//tested login module using xpath
	
	By email = By.xpath("//input[@id='input-email']");
//Give email 
	public void setEmail(String Email) {
		waitFor(driver.findElement(email));
		driver.findElement(email).sendKeys(Email);
	}
//Give password
	By password = By.xpath("//input[@id='input-password']");

	public void setPassword(String pass) {
		waitFor(driver.findElement(password));
		driver.findElement(password).sendKeys(pass);
	}
//Click on login
	By Login = By.xpath("//button[text()='Login']");

	public void clkLogin() {
		waitFor(driver.findElement(Login));
		driver.findElement(Login).click();
	}
}

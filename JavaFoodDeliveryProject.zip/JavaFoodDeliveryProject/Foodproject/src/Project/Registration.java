package Project;

import java.sql.*;
import java.util.Scanner;
public class Registration{
	//public static void main(String []args) throws SQLException {
	public void registration() throws SQLException {
		Driver d= new oracle.jdbc.driver.OracleDriver();
		DriverManager.registerDriver(d);		
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","FOODDELIVERY","project");
		Statement stmt=con.createStatement();
		Scanner sc=new Scanner(System.in);		
		System.out.println("Enter UserName: ");
		//User or admin only enter 25 characters
		String username=sc.next();
		System.out.println("Enter Password: ");
		//User or admin only enter 25 characters
		String password=sc.next();
		System.out.println("Enter Mobile Number: ");
		//User or admin only enter 10 numbers not taking alphabetics characters
		sc.nextLine();
		long mobileNumber=sc.nextLong();
		System.out.println("Enter Pin Number: ");
		//User or admin only enter 6 numbers not taking characters
		int pinNumber=sc.nextInt();
		ResultSet rs=stmt.executeQuery("insert into login values ('"+username+"','"+password+"','"+mobileNumber+"','"+pinNumber+"')");
		System.out.println("You are successfully registered");
		
		PreparedStatement stmt1=con.prepareStatement("select * from login");
		ResultSet result=stmt1.executeQuery();
		while(result.next()) {
			System.out.println("Your registered Details");
			System.out.println(" UserName: "+result.getString(1)+"\n Password: "+result.getString(2)+"\n Mobile Number: "+result.getString(3)+"\n Pin Number: "+result.getString(4));
		}
		
		}
	}

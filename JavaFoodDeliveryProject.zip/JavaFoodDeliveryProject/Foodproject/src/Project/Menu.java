package Project;


import java.sql.*;
import java.util.Scanner;

 

public class Menu extends Location{

//public static void main(String[] args) throws SQLException{
// TODO Auto-generated method stub

     public void menu() throws SQLException {
            // TODO Auto-generated method stub

Driver d = new oracle.jdbc.driver.OracleDriver();
DriverManager.registerDriver(d);
Connection c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","FOODDELIVERY","project");
Statement s= c.createStatement();
System.out.println("1         Veg Manchurian                  Rs.150");
System.out.println("2          Cream of Tomato Soup           Rs.99");
System.out.println("3          Paneer Butter Masala           Rs.260)");
System.out.println("4          Butter Chicken                 Rs.299");
System.out.println("5          Butter Naan                    Rs.69'");
System.out.println("6          Aloo Paratha                   Rs.80");
System.out.println("7          Chicken Biryani                Rs.199");
System.out.println("8          Veg Fried Rice                 Rs.190");
System.out.println("9          Chilli Chicken                 Rs.259");
System.out.println("10         IceCream                       Rs.80");
System.out.println("11         Faluda                         Rs.150");
Scanner sc = new Scanner(System.in);
System.out.println("Select the items to order");
//user enter only one number in the above list of the items
@SuppressWarnings("unused")
int button = sc.nextInt();
switch(button) {
case 1:
//Veg Manchurian
ResultSet rs=s.executeQuery("insert into Menu values(1,'Veg Manchurian','Rs.150')");
System.out.println("Veg Manchurian Rs.150");
System.out.println("Enter the desired Quantity: ");
int quantity =sc.nextInt();
int price=150;
int totalAmount=price*quantity;
System.out.println("Please Pay: "+totalAmount);
break;

 

case 2:
//Cream of Tomato Soup
rs=s.executeQuery("insert into Menu values(2,'Cream of Tomato Soup','Rs.99')");
System.out.println("Cream of Tomato Soup Rs.99");
System.out.println("Enter the desired Quantity: ");
quantity =sc.nextInt();
int price1=99;
totalAmount=price1*quantity;
System.out.println("Please Pay: "+totalAmount);
break;

 

case 3:
//Paneer Butter Masala
rs=s.executeQuery("insert into Menu values(3,'Paneer Butter Masala','Rs.260')");
System.out.println("Paneer Butter Masala Rs.260");
System.out.println("Enter the desired Quantity: ");
quantity = sc.nextInt();
int price2=260;
totalAmount=price2*quantity;
System.out.println("Please Pay: "+totalAmount);
break;

 

case 4:
//Butter Chicken
rs=s.executeQuery("insert into Menu values(4,'Butter Chicken','Rs.299')");
System.out.println("Butter Chicken Rs.299");
System.out.println("Enter the desired Quantity: ");
quantity = sc.nextInt();
int price3=299;
totalAmount=price3*quantity;
System.out.println("Please Pay: "+totalAmount);
break;

 

case 5:
//Butter Naan
rs=s.executeQuery("insert into Menu values(5,'Butter Naan','Rs.69')");
System.out.println("Butter Naan Rs.69");
System.out.println("Enter the desired Quantity: ");
quantity = sc.nextInt();
int price4=69;
totalAmount=price4*quantity;
System.out.println("Please Pay: "+totalAmount);
break;

 

case 6:
//Aloo Paratha
rs=s.executeQuery("insert into Menu values(6,'Aloo Paratha','Rs.80')");
System.out.println("Aloo Paratha Rs.80");
System.out.println("Enter the desired Quantity: ");
quantity = sc.nextInt();
int price5=80;
totalAmount=price5*quantity;
System.out.println("Please Pay: "+totalAmount);
break;

 

case 7:
//Chicken Biryani
rs=s.executeQuery("insert into Menu values(7,'Chicken Biryani','Rs.199')");
System.out.println("Chicken Biryani Rs.199");
System.out.println("Enter the desired Quantity: ");
quantity = sc.nextInt();
int price6=199;
totalAmount=price6*quantity;
System.out.println("Please Pay: "+totalAmount);
break;

 

case 8:
//Veg Fried Rice
rs=s.executeQuery("insert into Menu values(8,'Veg Fried Rice','Rs.190')");
System.out.println("Veg Fried Rice Rs.190");
System.out.println("Enter the desired Quantity: ");
quantity = sc.nextInt();
int price7=190;
totalAmount=price7*quantity;
System.out.println("Please Pay: "+totalAmount);
break;

 

case 9:
//Chilli Chicken
rs=s.executeQuery("insert into Menu values(9,'Chilli Chicken','Rs.259')");
System.out.println("Chilli Chicken Rs.259");
System.out.println("Enter the desired Quantity: ");
quantity = sc.nextInt();
int price8=259;
totalAmount=price8*quantity;
System.out.println("Please Pay: "+totalAmount);
break;

 

case 10:
//IceCream
rs=s.executeQuery("insert into Menu values(10,'IceCream','Rs.80')");
System.out.println("IceCream Rs.80");
System.out.println("Enter the desired Quantity: ");
quantity = sc.nextInt();
int price9=80;
totalAmount=price9*quantity;
System.out.println("Please Pay: "+totalAmount);
break;

 

case 11:
//Faluda
rs=s.executeQuery("insert into Menu values(11,'Faluda','Rs.150')");
System.out.println("Faluda Rs.150");
System.out.println("Enter the desired Quantity: ");
quantity = sc.nextInt();
int price10=150;
totalAmount=price10*quantity;
System.out.println("Please Pay: "+totalAmount);
break;
default:
System.out.println("Kindly select food items between 1-11 to order.");
menu();
System.out.println("Thank you for ordering.");
}
PreparedStatement stmt1=c.prepareStatement("select * from Menu");
ResultSet result=stmt1.executeQuery();
while(result.next()) {
	System.out.println("(: *** Your Order Details *** :)");
	System.out.println(" SNo : "+result.getString(1)+"\n Food Item : "+result.getString(2)+"\n Price : "+result.getString(3));
}
c.close();

}


}
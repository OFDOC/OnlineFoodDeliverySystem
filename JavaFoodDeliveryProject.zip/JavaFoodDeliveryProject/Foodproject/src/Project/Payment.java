package Project;

import java.util.Scanner;

public class Payment extends Menu{

  //public static void main(String[] args) {
        // TODO Auto-generated method stub

   public void payment() {
                // TODO Auto-generated method stub

@SuppressWarnings("resource")
Scanner sc= new Scanner(System.in);
System.out.println("Enter 1 for SBI, 2 for ICICI Bank or enter any number for other banks");
//User should enter above any one number
int bank = sc.nextInt();
switch(bank) {
case 1: 
System.out.println("You choose SBI");
break;
case 2:
System.out.println("You choose ICICI");
break;
default: System.out.println("Other banks");
break;
}
System.out.println("Enter 1 for Credit Card, Enter 2 for Debit Card");
//User should enter above any one number
int button= sc.nextInt();
switch(button) {
case 1:
System.out.println("Credit Card");
System.out.println("Enter Card Number: ");
    long C_cardNumber=sc.nextLong();
System.out.println("Enter Card Holder Name: ");
    String C_holderName=sc.next();
System.out.println("Enter CVV: ");
    sc.nextShort();
System.out.println("Pay Now");
System.out.println("Payment Successfull");
break;

 

case 2: System.out.println("Debit Card");
System.out.println("Enter Card Number: ");
    long D_cardNumber=sc.nextLong();
System.out.println("Enter Card Holder Name: ");
    String D_holderName=sc.next();
System.out.println("Enter CVV: ");
    sc.nextShort();
System.out.println("Pay Now");
System.out.println("Payment Successfull");
break;

 

default: {System.out.println("Choose Credit or Debit Card");
break;
}
}

}
}
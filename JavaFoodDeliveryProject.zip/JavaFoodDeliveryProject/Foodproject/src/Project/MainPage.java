package Project;
import java.sql.SQLException;
import java.util.Scanner;

public class MainPage {
	public static void main() throws SQLException {
		// TODO Auto-generated method stub
			Logout l=new Logout();
				System.out.println("(: *********  Welcome To Food Delivery System  ********* :)");
				System.out.println("1. Registration");
				System.out.println("2. Login");
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter either 1 or 2");
			int number=sc.nextInt();
			if(number<3 && number>0) {
			switch(number) {
		case 1:
			System.out.println("(: *********  Welcome To Food Delivery System  ********* :)");
			l.registration();
			System.out.println("(:*********  Thank you for Registering  *********:)");
			System.out.println();
			System.out.println("(: **********  Welcome to Login Page  ********** :)");
			l.login();
			System.out.println("(:*********  Thank you for login  *********:)");
			System.out.println();
			break;
			
		case 2:
			System.out.println("(: **********  Welcome to Login Page  ********** :)");
			l.login();
			System.out.println("(:*********  Thank you for login  *********:)");
			System.out.println();
			break;
			default :
				System.out.println("Enter the number between 1 to 7");
	
		}
		l.location();
		System.out.println("(:*********  Location Added Sucessfully  *********:)");
		System.out.println();
		l.menu();
		System.out.println("(:*********  Thank you for Ordering  *********:)");
		System.out.println();
		l.payment();
		System.out.println("(:*********  Thank you for Paying  *********:)");
		System.out.println();
		l.logout();
		}else {
			main();
		}
		
		
	}
	public static void main(String []args) throws SQLException {
		main();
}
}
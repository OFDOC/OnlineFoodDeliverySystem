package Project;

import java.sql.*;
import java.util.Scanner;

public class Login extends Registration{
	//public static void main(String []args) throws SQLException {
	public void login() throws SQLException { 
		Driver d= new oracle.jdbc.driver.OracleDriver();
		DriverManager.registerDriver(d);			
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","FOODDELIVERY","project");
		Statement stmt=con.createStatement();
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter UserName: ");
		String username=sc.nextLine();
		System.out.print("Enter Password: ");
		String password=sc.next();
		ResultSet rs=stmt.executeQuery("select * from login where username='"+username+"' and password='"+password+"'");
		if(rs.next()) {
		System.out.println("(: Login Successfull  :)");
		}else {
			System.out.println("(: *** Invalid Username and Password *** :)" +"\n"+ "(: *** Please re-enter password and username *** :)");
		login();
			
		
		}
		con.close();
		}

}